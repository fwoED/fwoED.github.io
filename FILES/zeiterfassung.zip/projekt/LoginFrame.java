

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class LoginFrame extends JFrame implements ActionListener {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;

    public LoginFrame() {
        setTitle("Login");
        setSize(300, 150);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2));

        JLabel usernameLabel = new JLabel("Benutzername:");
        usernameField = new JTextField();
        JLabel passwordLabel = new JLabel("Passwort:");
        passwordField = new JPasswordField();
        loginButton = new JButton("Anmelden");
        loginButton.addActionListener(this);

        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(new JLabel()); // Platzhalter für das Rasterlayout
        panel.add(loginButton);

        add(panel);
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginButton) {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());

            // Hier können Sie die Benutzerüberprüfung durchführen
            if (username.equals("root") && password.equals("")) {
                JOptionPane.showMessageDialog(this, "Anmeldung erfolgreich");
                // Hier können Sie den Hauptbildschirm oder die Hauptanwendung öffnen
            } else {
                JOptionPane.showMessageDialog(this, "Anmeldung fehlgeschlagen", "Fehler", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        try{
            
            Connection conn = connect_db.getConnection();}
        catch (SQLException d) {
                System.out.println("Connection failed!");
                throw new RuntimeException(d);
                }
        SwingUtilities.invokeLater(() -> {
            new LoginFrame().setVisible(true);
        });
    }
}
