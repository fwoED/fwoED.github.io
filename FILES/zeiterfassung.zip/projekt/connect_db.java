import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class connect_db {
    private static final String HOST = "jdbc:mysql://localhost";
    private static final int PORT = 3306;
    private static final String USER = "root";
    private static final String PW = "";
    private static final String DB_name = "zeiterfassung";

    public static Connection getConnection() throws SQLException{
        if(DriverManager.getConnection(HOST+":"+PORT+"/"+ DB_name, USER,PW) != null){
            System.out.println("Connection da!");
        }
        return DriverManager.getConnection(HOST+":"+PORT+"/"+ DB_name, USER,PW);
    }
}
