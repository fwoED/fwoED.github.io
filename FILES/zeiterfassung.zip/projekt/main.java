

public class main {
        public static void main(String[] args) {
            LoginFrame Menu = new LoginFrame();
        }
        
    }
