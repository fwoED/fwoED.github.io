//ZOO
//einfache darstellung der ZOO applikation
//erstellt von Clemens Babel 09.11.2023

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

interface Flyable {
    void fliegen();
}

abstract class Tiere {
    abstract String fressen();

    abstract String bewegen();

    abstract String geraeuschMachen();
}

class Elefant extends Tiere {
    String fressen() {
        return "Elefant frisst Gras";
    }

    String bewegen() {
        return "Elefant bewegt sich langsam";
    }

    String geraeuschMachen() {
        return "Elefant trötet";
    }
}

class Krokodil extends Tiere {
    String fressen() {
        return "Krokodil frisst Fleisch";
    }

    String bewegen() {
        return "Krokodil bewegt sich im Wasser";
    }

    String geraeuschMachen() {
        return "Krokodil knurrt";
    }
}

class Spatz extends Tiere implements Flyable {
    String fressen() {
        return "Spatz frisst Körner";
    }

    String bewegen() {
        return "Spatz bewegt sich schnell";
    }

    String geraeuschMachen() {
        return "Spatz tschilpt";
    }

    public void fliegen() {
        // Hier könnte man die Flugaktion in der GUI durchführen
    }
}

class TierGUI {
    private JFrame frame;
    private JTextArea outputArea;

    public TierGUI() {
        frame = new JFrame("Tier GUI");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JButton actionButton = new JButton("Aktionen ausführen");
        actionButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                durchfuehrenAktionen();
            }
        });

        outputArea = new JTextArea();
        outputArea.setEditable(false);

        frame.setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));
        frame.add(actionButton);
        frame.add(new JScrollPane(outputArea));

        frame.setVisible(true);
    }

    private void durchfuehrenAktionen() {
        ArrayList<Tiere> tierListe = new ArrayList<>();
        tierListe.add(new Elefant());
        tierListe.add(new Krokodil());
        tierListe.add(new Spatz());

        for (Tiere tier : tierListe) {
            outputArea.append("Aktionen für: " + tier.getClass().getSimpleName() + "\n");
            outputArea.append(tier.fressen() + "\n");
            outputArea.append(tier.bewegen() + "\n");
            outputArea.append(tier.geraeuschMachen() + "\n");

            if (tier instanceof Flyable) {
                ((Flyable) tier).fliegen();
                outputArea.append("Das Tier fliegt!\n");
            }

            outputArea.append("\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new TierGUI();
            }
        });
    }
}
