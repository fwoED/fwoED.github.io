//Game of life
//einfaches Game of Life spiel
//Säubern des Feldes stoppt auch
//erstellt von Clemens Babel 09.11.2023

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class GameOfLifeGUI implements ActionListener, ChangeListener {

    private JFrame frame;
    private JButton[][] gridButtons;
    private boolean[][] grid;
    private Timer timer;
    private JSlider speedSlider;
    private JButton startButton;
    private JButton stopButton;
    private JButton restartButton;
    private JButton clearButton;
    private JLabel speedLabel;

    private static final int GRID_SIZE = 30;
    private static final int CELL_SIZE = 20;
    private static final int DELAY = 200; // Milliseconds

    public GameOfLifeGUI() {
        frame = new JFrame("Conway's Game of Life");
        frame.setSize(GRID_SIZE * CELL_SIZE, GRID_SIZE * CELL_SIZE);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        gridButtons = new JButton[GRID_SIZE][GRID_SIZE];
        grid = new boolean[GRID_SIZE][GRID_SIZE];

        initializeGrid();
        initializeGUI();

        frame.setVisible(true);
    }

    private void initializeGrid() {
        // Initialize the grid randomly
        for (int i = 0; i < GRID_SIZE; i++) {
            for (int j = 0; j < GRID_SIZE; j++) {
                grid[i][j] = Math.random() < 0.3; // Initial live cells with 30% probability
            }
        }
    }

    private void initializeGUI() {
        frame.setLayout(new BorderLayout());

        // Create buttons for each cell in the grid
        JPanel gridPanel = new JPanel(new GridLayout(GRID_SIZE, GRID_SIZE));
        for (int i = 0; i < GRID_SIZE; i++) {
            for (int j = 0; j < GRID_SIZE; j++) {
                JButton button = new JButton();
                button.setPreferredSize(new Dimension(CELL_SIZE, CELL_SIZE));
                button.setBackground(grid[i][j] ? Color.BLACK : Color.WHITE);
                button.addActionListener(this);
                gridButtons[i][j] = button;
                gridPanel.add(button);
            }
        }

        frame.add(gridPanel, BorderLayout.CENTER);

        // Create control panel with buttons and slider
        JPanel controlPanel = new JPanel();
        startButton = new JButton("Start");
        stopButton = new JButton("Stop");
        restartButton = new JButton("Restart");
        clearButton = new JButton("Clear");
        speedSlider = new JSlider(0, 1000, DELAY);
        speedLabel = new JLabel("Speed: " + DELAY + " ms");

        startButton.addActionListener(this);
        stopButton.addActionListener(this);
        restartButton.addActionListener(this);
        clearButton.addActionListener(this);
        speedSlider.addChangeListener(this);

        controlPanel.add(startButton);
        controlPanel.add(stopButton);
        controlPanel.add(restartButton);
        controlPanel.add(clearButton);
        controlPanel.add(speedLabel);
        controlPanel.add(speedSlider);

        frame.add(controlPanel, BorderLayout.SOUTH);

        // Create a timer to update the grid periodically
        timer = new Timer(DELAY, this);
    }

    private void updateGrid() {
        boolean[][] newGrid = new boolean[GRID_SIZE][GRID_SIZE];

        // Apply the rules of Conway's Game of Life
        for (int i = 0; i < GRID_SIZE; i++) {
            for (int j = 0; j < GRID_SIZE; j++) {
                int liveNeighbors = countLiveNeighbors(i, j);

                if (grid[i][j]) {
                    newGrid[i][j] = liveNeighbors == 2 || liveNeighbors == 3;
                } else {
                    newGrid[i][j] = liveNeighbors == 3;
                }

                // Update the button color
                gridButtons[i][j].setBackground(newGrid[i][j] ? Color.BLACK : Color.WHITE);
            }
        }

        // Update the grid
        grid = newGrid;
    }

    private int countLiveNeighbors(int row, int col) {
        int count = 0;
        int[][] neighbors = {
                {-1, -1}, {-1, 0}, {-1, 1},
                {0, -1},           {0, 1},
                {1, -1}, {1, 0}, {1, 1}
        };

        for (int[] neighbor : neighbors) {
            int newRow = row + neighbor[0];
            int newCol = col + neighbor[1];

            if (newRow >= 0 && newRow < GRID_SIZE && newCol >= 0 && newCol < GRID_SIZE) {
                if (grid[newRow][newCol]) {
                    count++;
                }
            }
        }

        return count;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() instanceof JButton) {
            JButton sourceButton = (JButton) e.getSource();

            if (sourceButton == startButton) {
                timer.start();
            } else if (sourceButton == stopButton) {
                timer.stop();
            } else if (sourceButton == restartButton) {
                initializeGrid();
                updateGrid();
            } else if (sourceButton == clearButton) {
                clearGrid();
            } else {
                // Handle button click (toggle cell state)
                for (int i = 0; i < GRID_SIZE; i++) {
                    for (int j = 0; j < GRID_SIZE; j++) {
                        if (gridButtons[i][j] == sourceButton) {
                            grid[i][j] = !grid[i][j];
                            sourceButton.setBackground(grid[i][j] ? Color.BLACK : Color.WHITE);
                        }
                    }
                }
            }
        } else if (e.getSource() == timer) {
            // Handle timer tick (update grid)
            updateGrid();
        }
    }

    @Override
    public void stateChanged(ChangeEvent e) {
        // Handle slider change (adjust timer speed)
        timer.setDelay(speedSlider.getValue());
        speedLabel.setText("Speed: " + speedSlider.getValue() + " ms");
    }

    private void clearGrid() {
        for (int i = 0; i < GRID_SIZE; i++) {
            for (int j = 0; j < GRID_SIZE; j++) {
                grid[i][j] = false;
                gridButtons[i][j].setBackground(Color.WHITE);
            }
        }
        timer.stop();
    }
}
