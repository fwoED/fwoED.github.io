//TIC TAC TOE
//einfaches TIC TAC TOE spiel
//erstellt von Clemens Babel 09.11.2023

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class tictac implements ActionListener {
    private JFrame frame;
    private JButton[] buttons;
    private JLabel currentPlayerLabel;
    private JButton restartButton;
    private boolean xTurn = true;
    private boolean gameWon = false;

    public tictac() {
        frame = new JFrame("Tic-Tac-Toe");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        JPanel gamePanel = new JPanel(new GridLayout(3, 3));
        buttons = new JButton[9];
        for (int i = 0; i < 9; i++) {
            buttons[i] = new JButton("");
            buttons[i].setFont(new Font("Arial", Font.PLAIN, 48));
            buttons[i].setFocusable(false);
            buttons[i].addActionListener(this);
            gamePanel.add(buttons[i]);
        }

        currentPlayerLabel = new JLabel("Spieler: X");
        currentPlayerLabel.setHorizontalAlignment(SwingConstants.CENTER);

        restartButton = new JButton("Neustart");
        restartButton.addActionListener(e -> restartGame());

        frame.add(gamePanel, BorderLayout.CENTER);
        JPanel infoPanel = new JPanel(new GridLayout(3, 1));
        infoPanel.add(currentPlayerLabel);
        infoPanel.add(restartButton);
        frame.add(infoPanel, BorderLayout.SOUTH);

        frame.setSize(300, 400);
        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (!gameWon) {
            JButton button = (JButton) e.getSource();
            if (button.getText().isEmpty()) {
                if (xTurn) {
                    button.setText("X");
                } else {
                    button.setText("O");
                }
                xTurn = !xTurn;
                currentPlayerLabel.setText("Spieler: " + (xTurn ? "X" : "O"));

                if (checkForWin()) {
                    gameWon = true;
                    int[] winningIndices = getWinningLine();
                    highlightWinningLine(winningIndices);
                    currentPlayerLabel.setText("Gewonnen: " + (xTurn ? "O" : "X"));
                }
            }
        }
    }

    private boolean checkForWin() {
        return (checkRows() || checkColumns() || checkDiagonals());
    }

    private boolean checkRows() {
        for (int i = 0; i < 3; i++) {
            int firstIndex = i * 3;
            int secondIndex = firstIndex + 1;
            int thirdIndex = firstIndex + 2;
            if (!buttons[firstIndex].getText().isEmpty() &&
                buttons[firstIndex].getText().equals(buttons[secondIndex].getText()) &&
                buttons[firstIndex].getText().equals(buttons[thirdIndex].getText())) {
                return true;
            }
        }
        return false;
    }

    private boolean checkColumns() {
        for (int i = 0; i < 3; i++) {
            int firstIndex = i;
            int secondIndex = i + 3;
            int thirdIndex = i + 6;
            if (!buttons[firstIndex].getText().isEmpty() &&
                buttons[firstIndex].getText().equals(buttons[secondIndex].getText()) &&
                buttons[firstIndex].getText().equals(buttons[thirdIndex].getText())) {
                return true;
            }
        }
        return false;
    }

    private boolean checkDiagonals() {
        if (!buttons[0].getText().isEmpty() &&
            buttons[0].getText().equals(buttons[4].getText()) &&
            buttons[0].getText().equals(buttons[8].getText())) {
            return true;
        }

        if (!buttons[2].getText().isEmpty() &&
            buttons[2].getText().equals(buttons[4].getText()) &&
            buttons[2].getText().equals(buttons[6].getText())) {
            return true;
        }
        return false;
    }

    private int[] getWinningLine() {
        for (int i = 0; i < 3; i++) {
            int firstIndex = i * 3;
            int secondIndex = firstIndex + 1;
            int thirdIndex = firstIndex + 2;
            if (!buttons[firstIndex].getText().isEmpty() &&
                buttons[firstIndex].getText().equals(buttons[secondIndex].getText()) &&
                buttons[firstIndex].getText().equals(buttons[thirdIndex].getText())) {
                return new int[]{firstIndex, secondIndex, thirdIndex};
            }
        }

        for (int i = 0; i < 3; i++) {
            int firstIndex = i;
            int secondIndex = i + 3;
            int thirdIndex = i + 6;
            if (!buttons[firstIndex].getText().isEmpty() &&
                buttons[firstIndex].getText().equals(buttons[secondIndex].getText()) &&
                buttons[firstIndex].getText().equals(buttons[thirdIndex].getText())) {
                return new int[]{firstIndex, secondIndex, thirdIndex};
            }
        }

        if (!buttons[0].getText().isEmpty() &&
            buttons[0].getText().equals(buttons[4].getText()) &&
            buttons[0].getText().equals(buttons[8].getText())) {
            return new int[]{0, 4, 8};
        }
        if (!buttons[2].getText().isEmpty() &&
            buttons[2].getText().equals(buttons[4].getText()) &&
            buttons[2].getText().equals(buttons[6].getText())) {
            return new int[]{2, 4, 6};
        }

        return null;
    }

    private void highlightWinningLine(int[] winningIndices) {
        if (winningIndices != null) {
            for (int index : winningIndices) {
                buttons[index].setBackground(Color.GREEN);
            }
        }
    }

    private void restartGame() {
        for (int i = 0; i < 9; i++) {
            buttons[i].setText("");
            buttons[i].setBackground(null);
        }
        xTurn = true;
        gameWon = false;
        currentPlayerLabel.setText("Spieler: X");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new tictac();
        });
    }
}
