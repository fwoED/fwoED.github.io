//Fibonacci
//einfache darstellung der Fibonacci Reihe über eine GUI
//erstellt von Clemens Babel 09.11.2023

import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class fibonachi implements ActionListener {
    private JFrame frame;
    private JTextField inputFieldM;
    private JButton calculateButton;
    private JTextArea resultTextArea; // Use JTextArea for displaying the sequence

    public fibonachi() {
        frame = new JFrame("Fibonacci Reihe");

        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(new GridLayout(0, 2));
        frame.setLocationRelativeTo(null);

        inputFieldM = new JTextField(15);

        calculateButton = new JButton("Berechnen");
        resultTextArea = new JTextArea(10, 30); // Create a JTextArea for displaying the sequence
        resultTextArea.setEditable(false); // Make it non-editable

        calculateButton.addActionListener(this);

        frame.add(new JLabel("Start Zahl (m):"));
        frame.add(inputFieldM);
        frame.add(calculateButton);
        frame.add(resultTextArea); // Add the JTextArea to the frame

        frame.pack();
        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == calculateButton) {
            try {
                int m = Integer.parseInt(inputFieldM.getText());
                int second = 0;
                int next = 0;
                int n = m;
                resultTextArea.setText(""); // Clear the text area
                while (next < 1000) {
                    resultTextArea.append( next + "\n"); // Append the sequence to the JTextArea
                    next = n + second;
                    n = second;
                    second = next;
                }
            } catch (NumberFormatException ex) {
                resultTextArea.setText("Ungültige Eingabe. Bitte geben Sie ganze Zahlen ein.");
            }
        }
    }
}
