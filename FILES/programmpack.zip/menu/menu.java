//Hauptmenü
//Auswahl ob man ALgorithmen oder Spiele öffnen möchte
//erstellt von Clemens Babel 09.11.2023
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Action;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;

public class menu implements ActionListener{
    JFrame frame = new JFrame();
    JButton button = new JButton("Algorithmen");
    JButton button1 = new JButton("Spiele");
    menu(){
        
        button.setFocusable(false);
        button1.setFocusable(false);
        frame.setTitle("Menu");
        frame.setSize(150,150);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        

        Container pane = frame.getContentPane();
        GroupLayout gl = new GroupLayout(pane);
        pane.setLayout(gl);

        button.addActionListener(this);
        button1.addActionListener(this);
            
        gl.setHorizontalGroup(
            gl.createParallelGroup(GroupLayout.Alignment.CENTER)
                .addComponent(button)
                .addComponent(button1)
        );
        gl.setVerticalGroup(
            gl.createSequentialGroup()
                .addComponent(button)
                .addComponent(button1)
        );
        

        gl.setAutoCreateContainerGaps(true);
        frame.setVisible(true);
    }
    @Override
            public void actionPerformed(ActionEvent e){
                if(e.getSource()==button){
                frame.dispose();
                algorithmen myAlgorithmen = new algorithmen();
            }
                else if(e.getSource()==button1)
            {
                frame.dispose();
                spiele mySpiele = new spiele();
            }}
    }


