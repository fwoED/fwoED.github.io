//Euklid
//einfache GUI um sich Euklid zu berechnen
//erstellt von Clemens Babel 09.11.2023

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class euklid implements ActionListener {
    private JFrame frame;
    private JTextField inputFieldM;
    private JTextField inputFieldN;
    private JButton calculateButton;
    private JLabel resultLabel;

    public euklid() {
        frame = new JFrame("Euklid'scher Algorithmus");

        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(new GridLayout(0, 2));
        frame.setLocationRelativeTo(null);

        inputFieldM = new JTextField(15);
        inputFieldN = new JTextField(15);
        calculateButton = new JButton("Berechnen");
        resultLabel = new JLabel("Ergebnis wird hier angezeigt");
        resultLabel.setPreferredSize(new Dimension(250, 50));

        calculateButton.addActionListener(this);

        frame.add(new JLabel("Erste Zahl (m):"));
        frame.add(inputFieldM);
        frame.add(new JLabel("Zweite Zahl (n):"));
        frame.add(inputFieldN);
        frame.add(calculateButton);
        frame.add(resultLabel);

        frame.pack();
        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == calculateButton) {
            try {
                int m = Integer.parseInt(inputFieldM.getText());
                int n = Integer.parseInt(inputFieldN.getText());

                int r = m % n;
                while (r > 0) {
                    m = n;
                    n = r;
                    r = m % n;
                }

                resultLabel.setText("Größte gemeinsame Teiler ist: " + n);
            } catch (NumberFormatException ex) {
                resultLabel.setText("Ungültige Eingabe. Bitte geben Sie ganze Zahlen ein.");
            }
        }
    }
}
