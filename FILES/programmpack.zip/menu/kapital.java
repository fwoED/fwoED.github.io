//Kapital Verdoppelung
//einfache gui um die Kapitalverdoppelung anzuzeigen
//erstellt von Clemens Babel 09.11.2023

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class kapital implements ActionListener {
    private JFrame frame;
    private JTextField inputFieldM;
    private JTextField inputFieldN;
    private JButton calculateButton;
    private JLabel resultLabel;

    public kapital() {
        frame = new JFrame("Kapitalverdoppelung");

        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(new GridLayout(0, 2));
        frame.setLocationRelativeTo(null);

        inputFieldM = new JTextField(15);
        inputFieldN = new JTextField(15);
        calculateButton = new JButton("Berechnen");
        resultLabel = new JLabel("<html>Ergebnis wird hier angezeigt</html>");
        resultLabel.setPreferredSize(new Dimension(250, 80));

        calculateButton.addActionListener(this);

        frame.add(new JLabel("Startkapital"));
        frame.add(inputFieldM);
        frame.add(new JLabel("Zinssatz"));
        frame.add(inputFieldN);
        frame.add(calculateButton);
        frame.add(resultLabel);

        frame.pack();
        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == calculateButton) {
            try {
                double m = Double.parseDouble(inputFieldM.getText());
                double n = Double.parseDouble(inputFieldN.getText());
                int Jahr = 0;
                double Kapital = m;
                do {
                    Kapital = Kapital * (1 + n / 100);
                    Jahr += 1;
                } while (Kapital < 2 * m);
                resultLabel.setText("<html>Nach " + Jahr + " Jahren hat sich<br>das Kapital auf " + String.format("%.2f", Kapital) + " Euro verdoppelt</html>");
            } catch (NumberFormatException ex) {
                resultLabel.setText("Ungültige Eingabe");
            }
        }
    }
}
