 //Algorithmen Menü
//einfaches Menü zum auswählen der Algorithmen
//erstellt von Clemens Babel 09.11.2023
 
 import java.awt.Container;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class algorithmen implements ActionListener {
    JFrame frame = new JFrame();

    JButton button1 = new JButton("Euklid");
    JButton button2 = new JButton("Fibonachi");
    JButton button3 = new JButton("Kapitalverdoppelung");
    JButton button4 = new JButton("Schaltjahrberechnung");
    JButton button5 = new JButton("Zurück");

    algorithmen() {
        frame.setTitle("Algorithmen");
        frame.setSize(200, 200);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Container pane = frame.getContentPane();
        GroupLayout gl = new GroupLayout(pane);
        pane.setLayout(gl);
        button1.setFocusable(false);
        button2.setFocusable(false);
        button3.setFocusable(false);
        button4.setFocusable(false);
        button5.setFocusable(false);
        button1.addActionListener(this);
        button2.addActionListener(this);
        button3.addActionListener(this);
        button4.addActionListener(this);
        button5.addActionListener(this);

        gl.setHorizontalGroup(
            gl.createParallelGroup(GroupLayout.Alignment.CENTER)
                .addComponent(button1)
                .addComponent(button2)
                .addComponent(button3)
                .addComponent(button4)
                .addComponent(button5)
        );
        gl.setVerticalGroup(
            gl.createSequentialGroup()
                .addComponent(button1)
                .addComponent(button2)
                .addComponent(button3)
                .addComponent(button4)
                .addComponent(button5)
        );

        gl.setAutoCreateContainerGaps(true);

        frame.setVisible(true);
    }
    @Override
            public void actionPerformed(ActionEvent e){
                if(e.getSource()==button1){
                euklid myEuklid = new euklid();}
                else if(e.getSource()==button2)
                {
                
                fibonachi myFibo= new fibonachi();}
                else if(e.getSource()==button3)
                {
                
                kapital myKapital = new kapital();}
                else if(e.getSource()==button4)
                {
                
                schaltjahr mySchalt = new schaltjahr();}
                else if(e.getSource()==button5){
                frame.dispose();
                menu myMenu = new menu();
                }

            }
        }