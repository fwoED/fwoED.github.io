//Spielemenü
//Auswahl aller Spiele
//Tic Tac Toe und Hangman wurden hauptsächlich händich gemacht mit unterstützung ChatGPT und google
//Game of life und Zoo sind fast komplett von ChatGPT erstellt.
//erstellt von Clemens Babel 09.11.2023
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class spiele implements ActionListener {
    JFrame frame = new JFrame();

    JButton button1 = new JButton("Tic Tac Toe");
    JButton button2 = new JButton("Hangman");
    JButton button3 = new JButton("Game of life");
    JButton button4 = new JButton("Zoo");
    JButton button5 = new JButton("Zurück");

    spiele() {

        frame.setTitle("Spiel Menu");
        frame.setSize(150, 200);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        Container pane = frame.getContentPane();
        GroupLayout gl = new GroupLayout(pane);
        pane.setLayout(gl);
        button1.setFocusable(false);
        button2.setFocusable(false);
        button3.setFocusable(false);
        button4.setFocusable(false);
        button5.setFocusable(false);
        button1.addActionListener(this);
        button2.addActionListener(this);
        button3.addActionListener(this);
        button4.addActionListener(this);
        button5.addActionListener(this);

        gl.setHorizontalGroup(
            gl.createParallelGroup(GroupLayout.Alignment.CENTER)
                .addComponent(button1)
                .addComponent(button2)
                .addComponent(button3)
                .addComponent(button4)
                .addComponent(button5)
        );
        gl.setVerticalGroup(
            gl.createSequentialGroup()
                .addComponent(button1)
                .addComponent(button2)
                .addComponent(button3)
                .addComponent(button4)
                .addComponent(button5)
        );

        gl.setAutoCreateContainerGaps(true);

        frame.setVisible(true);
    }
    @Override
            public void actionPerformed(ActionEvent e){
                if(e.getSource()==button1){
                tictac myTictac = new tictac();}
                else if(e.getSource()==button2)
                {
                
                HangmanGUI myHang= new HangmanGUI();}
                else if(e.getSource()==button3)
                {
                
                GameOfLifeGUI myGame = new GameOfLifeGUI();}
                else if(e.getSource()==button4)
                {
                
                TierGUI myZoo = new TierGUI();}
                else if(e.getSource()==button5)
                {
                frame.dispose();
                menu myMenu = new menu();
                }

            }
        }
    

