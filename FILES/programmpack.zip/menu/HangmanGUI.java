//HANGMAN
//einfaches Hangman spiel
//erstellt von Clemens Babel 09.11.2023

import javax.swing.*;
import javax.swing.text.MaskFormatter;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;

public class HangmanGUI implements ActionListener {
    private JFrame frame;
    private JTextField wort;
    private JFormattedTextField buchstabe;
    private JButton uebergeben;
    private JButton neustart;
    private JButton speichern;
    private JLabel bild;
    private JLabel loesung;
    private JLabel eingegebeneb;
    private JEditorPane nutzb;
    private JLabel versuche;
    private JLabel eingabefeldb;
    private JLabel eingabefeldw;
    private String loesungswort = "";
    private String aktuelleAnzeige = "";
    private int falscheVersuche = 0;
    private StringBuilder coloredText = new StringBuilder("<html>");
    private boolean spielAktiv = true;

    private static final int MAX_VERSUCHE = 11;
    private static final String BILDPFAD_TUMBLING = "Hangman/tumbling.gif";
    private static final String BILDPFAD_GROUND = "Hangman/ground.jpg";

    public HangmanGUI() {
        frame = new JFrame("Hangman");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(550, 275);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.X_AXIS));

        JPanel bildPanel = new JPanel();
        bildPanel.setLayout(new BoxLayout(bildPanel, BoxLayout.Y_AXIS));

        wort = new JTextField(10);
        buchstabe = new JFormattedTextField(0);
        MaskFormatter mask = null;
        try {
        mask = new MaskFormatter("L");
        mask.setValidCharacters("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"); 
        } catch (ParseException e) {
        e.printStackTrace();
        }

        buchstabe = new JFormattedTextField(mask);
        uebergeben = new JButton("Prüfen");
        neustart = new JButton("Neustart");
        speichern = new JButton("Speichern");
        eingegebeneb = new JLabel("Eingegebene Buchstaben:");
        nutzb = new JEditorPane("text/html", "");
        nutzb.setEditable(false);
        nutzb.setFocusable(false);
        JScrollPane nutzbScrollPane = new JScrollPane(nutzb);
        nutzb.setPreferredSize(new Dimension(250, 45));
        versuche = new JLabel("Versuche: " + falscheVersuche + "/" + MAX_VERSUCHE);
        eingabefeldb = new JLabel("Buchstabe:");
        eingabefeldw = new JLabel("Wort:");

        bild = new JLabel();
        ImageIcon bild1 = new ImageIcon(getClass().getResource(BILDPFAD_TUMBLING));
        bild.setIcon(bild1);
        bildPanel.add(bild);
        bildPanel.add(versuche);

        JPanel elementePanel = new JPanel();
        elementePanel.setLayout(new BoxLayout(elementePanel, BoxLayout.Y_AXIS));

        loesung = new JLabel("Hier ist dein Rätsel");
        JPanel raetselPanel = new JPanel();
        raetselPanel.setLayout(new BoxLayout(raetselPanel, BoxLayout.X_AXIS));
        raetselPanel.add(loesung);

        JPanel worteingabePanel = new JPanel();
        worteingabePanel.add(eingabefeldw);
        worteingabePanel.setLayout(new BoxLayout(worteingabePanel, BoxLayout.X_AXIS));
        wort.setMaximumSize(new Dimension(125, 25));
        worteingabePanel.add(wort);
        worteingabePanel.add(Box.createRigidArea(new Dimension(10, 0)));
        worteingabePanel.add(speichern);

        JPanel buchstabenPanel = new JPanel();
        buchstabenPanel.add(eingabefeldb);
        buchstabenPanel.setLayout(new BoxLayout(buchstabenPanel, BoxLayout.X_AXIS));
        buchstabe.setMaximumSize(new Dimension(20, 25));
        buchstabenPanel.add(buchstabe);
        buchstabenPanel.add(uebergeben);
        buchstabenPanel.add(neustart);

        JPanel eingegebenPanel = new JPanel();
        eingegebenPanel.setLayout(new BoxLayout(eingegebenPanel, BoxLayout.X_AXIS));
        eingegebenPanel.add(Box.createRigidArea(new Dimension(5, 10)));
        eingegebenPanel.add(eingegebeneb);
        eingegebenPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        eingegebenPanel.add(nutzb);
        eingegebenPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        eingegebenPanel.setMaximumSize(new Dimension(350, 50));

        elementePanel.add(raetselPanel);
        elementePanel.add(Box.createRigidArea(new Dimension(0, 10)));
        elementePanel.add(worteingabePanel);
        elementePanel.add(Box.createRigidArea(new Dimension(0, 10)));
        elementePanel.add(buchstabenPanel);
        elementePanel.add(eingegebenPanel);

        mainPanel.add(bildPanel);
        mainPanel.add(elementePanel);

        speichern.addActionListener(this);
        uebergeben.addActionListener(this);
        neustart.addActionListener(this);

        frame.add(mainPanel);
        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == speichern) {
            loesungswort = wort.getText();
            aktuelleAnzeige = createUnderscores(loesungswort.length());
            loesung.setText(aktuelleAnzeige);
            wort.setText("");
            loesung.setForeground(Color.BLACK);
            versuche.setForeground(Color.BLACK);
            nutzb.setText("");
            ImageIcon bildg = new ImageIcon(getClass().getResource(BILDPFAD_GROUND));
            bild.setIcon(bildg);
            falscheVersuche = 0;
            versuche.setText("Versuche: " + falscheVersuche + "/" + MAX_VERSUCHE);
            versuche.setForeground(Color.BLACK);
            coloredText = new StringBuilder("<html>");
            spielAktiv = true;
        } else if ((e.getSource() == uebergeben) && (!buchstabe.getText().trim().isEmpty()) && spielAktiv) {
            checkBuchstabe(Character.toLowerCase(buchstabe.getText().charAt(0)));
            buchstabe.setText("");
        } else if ((e.getSource() == uebergeben) && (buchstabe.getText().trim().isEmpty()) && (!wort.getText().trim().isEmpty()) && spielAktiv) {
            String eingabe = wort.getText();
            if (eingabe.equalsIgnoreCase(loesungswort)) {
                loesung.setText(loesungswort);
                loesung.setForeground(Color.GREEN);
                versuche.setForeground(Color.GREEN);
                versuche.setText("GEWONNEN");
                spielAktiv = false;
            } else {
                falscheVersuche++;
                if (falscheVersuche < MAX_VERSUCHE) {
                    ImageIcon bildIcon = new ImageIcon(getClass().getResource("hangman/try" + falscheVersuche + ".gif"));
                    bild.setIcon(bildIcon);
                    versuche.setText("Versuche: " + falscheVersuche + "/" + MAX_VERSUCHE);
                } else if (falscheVersuche == MAX_VERSUCHE) {
                    loesung.setText("VERLOREN");
                    ImageIcon bildIcon = new ImageIcon(getClass().getResource("hangman/try11.gif"));
                    bild.setIcon(bildIcon);
                    versuche.setForeground(Color.RED);
                    versuche.setText("Versuche: " + MAX_VERSUCHE + "/" + MAX_VERSUCHE);
                    loesung.setBackground(Color.RED);
                    spielAktiv = false;
                }
            }
            wort.setText("");
        } else if (e.getSource() == neustart) {
            resetGame();
        }

        if (aktuelleAnzeige.indexOf('_') == -1 || falscheVersuche == MAX_VERSUCHE) {
            endGame();
            return;
        }

        if (!spielAktiv) {
            return;
        }
    }

    private String createUnderscores(int length) {
        StringBuilder underscores = new StringBuilder();
        for (int i = 0; i < length; i++) {
            underscores.append('_');
            underscores.append(' ');
        }
        return underscores.toString();
    }

    private void checkBuchstabe(char eingebuchstabe) {
        boolean istRichtig = false;
        for (int i = 0; i < loesungswort.length(); i++) {
            if (Character.toLowerCase(loesungswort.charAt(i)) == eingebuchstabe) {
                istRichtig = true;
                aktuelleAnzeige = aktuelleAnzeige.substring(0, 2 * i) + loesungswort.charAt(i) + aktuelleAnzeige.substring(2 * i + 1);
            }
        }

        loesung.setText(aktuelleAnzeige);
        updateUsedLetters(eingebuchstabe, istRichtig);
        buchstabe.setText("");
        buchstabe.setFocusLostBehavior(JFormattedTextField.COMMIT);
    }

    private void resetGame() {
        falscheVersuche = 0;
        versuche.setText("Versuche: " + falscheVersuche + "/" + MAX_VERSUCHE);
        loesungswort = "";
        aktuelleAnzeige = "";
        loesung.setText("");
        nutzb.setText("");
        coloredText = new StringBuilder("<html>");
        ImageIcon bildIcon = new ImageIcon(getClass().getResource(BILDPFAD_TUMBLING));
        bild.setIcon(bildIcon);
        spielAktiv = true;
        versuche.setForeground(Color.BLACK);
    }

    private void endGame() {
        spielAktiv = false;
        loesung.setForeground(falscheVersuche == MAX_VERSUCHE ? Color.RED : Color.GREEN);
    }

    private void updateUsedLetters(char buchstabe, boolean istRichtig) {
        if (istRichtig) {
            coloredText.append("<font color='green'> ").append(buchstabe).append("</font>");
        } else {
            coloredText.append("<font color='red'> ").append(buchstabe).append("</font>");
            falscheVersuche++;

            if (falscheVersuche < MAX_VERSUCHE) {
                ImageIcon bildIcon = new ImageIcon(getClass().getResource("hangman/try" + falscheVersuche + ".gif"));
                bild.setIcon(bildIcon);
                versuche.setText("Versuche: " + falscheVersuche + "/" + MAX_VERSUCHE);
            } else if (falscheVersuche == MAX_VERSUCHE) {
                loesung.setText("VERLOREN");
                ImageIcon bildIcon = new ImageIcon(getClass().getResource("hangman/try11.gif"));
                bild.setIcon(bildIcon);
                versuche.setText("Versuche: " + MAX_VERSUCHE + "/" + MAX_VERSUCHE);
                loesung.setForeground(Color.RED);
            }
        }
        nutzb.setText(coloredText.toString());
    }
}
