//Schaltjahr
//Einfaches Programm mit GUI um Jahr auf Schaltjahr zu überprüfen
//erstellt von Clemens Babel 09.11.2023

import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class schaltjahr implements ActionListener {
    private JFrame frame;
    private JTextField inputFieldM;
    private JButton calculateButton;
    private JLabel resultLabel;

    public schaltjahr() {
        frame = new JFrame("Schaltjahr");

        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(new GridBagLayout()); // Use GridBagLayout

        inputFieldM = new JTextField(5);

        calculateButton = new JButton("Berechnen");
        resultLabel = new JLabel("Ergebnis");
        resultLabel.setPreferredSize(new Dimension(180,80));

        calculateButton.addActionListener(this);

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 5, 5, 5); // Add some padding

        // Add JLabel "Jahr:" centered
        c.gridwidth = 2; // Span 2 columns
        c.anchor = GridBagConstraints.CENTER;
        frame.add(new JLabel("Jahr:"), c);

        c.gridwidth = 1; // Reset gridwidth
        c.gridx = 2; // Move to the next column
        frame.add(inputFieldM, c);

        c.gridx = 3;
        frame.add(calculateButton, c);

        c.gridx = 4;
        frame.add(resultLabel, c);

        frame.pack();
        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == calculateButton) {
            try {
                int m = Integer.parseInt(inputFieldM.getText());
                int jahr = m;
                if (jahr % 4 == 0 && (jahr % 100 != 0 || jahr % 400 == 0)) {
                    resultLabel.setText(jahr + " ist ein Schaltjahr");
                } else {
                    resultLabel.setText(jahr + " ist kein Schaltjahr");
                }
            } catch (NumberFormatException ex) {
                resultLabel.setText("Ungültige Eingabe");
            }
        }
    }
}
