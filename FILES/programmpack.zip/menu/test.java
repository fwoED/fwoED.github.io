import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class test implements ActionListener {
    private JFrame frame = new JFrame();
    private JButton button5 = new JButton("Zurück");
    private String[] algorithmLabels = { "Euklid", "Fibonachi", "Kapitalverdoppelung", "Schaltjahrberechnung" };

    public test() {
        frame.setTitle("Algorithmen");
        frame.setSize(200, 200);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Container pane = frame.getContentPane();
        GroupLayout gl = new GroupLayout(pane);
        pane.setLayout(gl);

        button5.setFocusable(false);
        button5.addActionListener(this);

        gl.setAutoCreateContainerGaps(true);

        GroupLayout.SequentialGroup vGroup = gl.createSequentialGroup();
        vGroup.addComponent(button5);

        for (String algorithmLabel : algorithmLabels) {
            JButton algorithmButton = new JButton(algorithmLabel);
            algorithmButton.setFocusable(false);
            algorithmButton.addActionListener(this);
            vGroup.addComponent(algorithmButton);
        }

        gl.setVerticalGroup(vGroup);
        gl.linkSize(SwingConstants.HORIZONTAL, button5);

        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == button5) {
            frame.dispose();
            Menu myMenu = new Menu();
        } else {
            // Handle algorithm button clicks based on the button's label
            String label = ((JButton) e.getSource()).getText();
            if ("Euklid".equals(label)) {
                // Handle Euklid algorithm
                Euklid myEuklid = new Euklid();
            } else if ("Fibonachi".equals(label)) {
                // Handle Fibonachi algorithm
                Fibonachi myFibo = new Fibonachi();
            } else if ("Kapitalverdoppelung".equals(label)) {
                // Handle Kapitalverdoppelung algorithm
                Kapital myKapital = new Kapital();
            } else if ("Schaltjahrberechnung".equals(label)) {
                // Handle Schaltjahrberechnung algorithm
                schaltjahr mySchalt = new Schaltjahr();
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Algorithmen());
    }
}
