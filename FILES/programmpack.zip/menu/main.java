//Start der GUI
//Einstieg des Programms
//erstellt von Clemens Babel 09.11.2023

public class main {
    public static void main(String[] args) {
        menu Menu = new menu();
    }
    
}
